package umg.edu.gt.desarrollo.estructuradedatos2025.ejercicios;

import java.util.LinkedList;
import java.util.HashSet;

public class EjercicioLinkedList {
   
    // Ejercicio 1: método que elimine los valores duplicados
    public static LinkedList<Integer> eliminarDuplicados(LinkedList<Integer> lista) {
        if (lista == null) {
            throw new IllegalArgumentException("La lista no puede estar vacia"); 
        }

        HashSet<Integer> conjunto = new HashSet<>();
        LinkedList<Integer> resultado = new LinkedList<>();

        for (Integer num : lista) {
            if (!conjunto.contains(num)) {
                conjunto.add(num);
                resultado.add(num);
            }
        }

        return resultado;
    }
    
    // Ejercicio 2: método que invierta los elementos de una LinkedList<String> sin usar otra lista o ArrayList.
    public static void invertirLinkedList(LinkedList<String> lista) {
        if (lista == null) {
            throw new IllegalArgumentException("La lista no puede estar vacia");
        }

        int left = 0;
        int right = lista.size() - 1;

        while (left < right) {
            // Intercambiar elementos
            String temp = lista.get(left);
            lista.set(left, lista.get(right));
            lista.set(right, temp);
            
            left++;
            right--;
        }
    }
    
    // Ejercicio 3: método que devuelva una nueva LinkedList<Integer> con los elementos de ambas listas intercalados en orden
    public static LinkedList<Integer> intercalarListas(LinkedList<Integer> lista1, LinkedList<Integer> lista2) {
        LinkedList<Integer> resultado = new LinkedList<>();
        
        if (lista1 == null || lista2 == null) {
            throw new IllegalArgumentException("Las listas no puede estar vacia");
        }
        
        // Recorremos las listas 
        while (!lista1.isEmpty() && !lista2.isEmpty()) {
            if (lista1.getFirst() < lista2.getFirst()) {
                resultado.add(lista1.poll());
            } else {
                resultado.add(lista2.poll());
            }
        }
        
        // Agrega elementos restantes
        resultado.addAll(lista1);
        resultado.addAll(lista2);
        
        return resultado;
    }
    
    // Método main para probar los ejercicios
    public static void main(String[] args) {
        // Prueba del Ejercicio 1
        LinkedList<Integer> lista1 = new LinkedList<>();
        lista1.add(1);
        lista1.add(2);
        lista1.add(2);
        lista1.add(3);
        System.out.println("Lista original: " + lista1);
        System.out.println("Lista sin duplicados: " + eliminarDuplicados(lista1));
        
        // Prueba del Ejercicio 2
        LinkedList<String> lista2 = new LinkedList<>();
        lista2.add("A");
        lista2.add("B");
        lista2.add("C");
        System.out.println("Lista original: " + lista2);
        invertirLinkedList(lista2);
        System.out.println("Lista invertida: " + lista2);
        
        // Prueba del Ejercicio 3
        LinkedList<Integer> lista3 = new LinkedList<>();
        lista3.add(1);
        lista3.add(3);
        lista3.add(5);
        
        LinkedList<Integer> lista4 = new LinkedList<>();
        lista4.add(2);
        lista4.add(4);
        lista4.add(6);
        
        System.out.println("Lista intercalada: " + intercalarListas(lista3, lista4));
    }
}