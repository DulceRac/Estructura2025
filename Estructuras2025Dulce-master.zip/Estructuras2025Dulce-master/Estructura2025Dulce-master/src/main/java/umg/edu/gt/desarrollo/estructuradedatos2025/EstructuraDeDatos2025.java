/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package umg.edu.gt.desarrollo.estructuradedatos2025;
import org.apache.log4j.Logger;

/**
 *
 * @author wcordova
 */
public class EstructuraDeDatos2025 {
	
	private static final Logger logger = Logger.getLogger(EstructuraDeDatos2025.class);
	

    public static void main(String[] args) {
    	logger.info("Bienvenidos a Programacion 3");
    }
    

}
